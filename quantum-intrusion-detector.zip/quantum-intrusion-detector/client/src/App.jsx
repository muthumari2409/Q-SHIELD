import React, { useState, useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import Navbar from './components/Navbar';
import QuantumCanvas from './components/QuantumCanvas';
import MetricCard from './components/MetricCard';
import ControlPanel from './components/ControlPanel';
import QuantumChatTransmitter from './components/QuantumChatTransmitter';
import BellStateVisualizer from './components/BellStateVisualizer';
import PhotonStreamTable from './components/PhotonStreamTable';
import IncidentLog from './components/IncidentLog';
import BenchmarkModal from './components/BenchmarkModal';
import ReportExportModal from './components/ReportExportModal';

import { 
  fetchHealth, 
  fetchPresets, 
  runSimulation, 
  fetchIncidents, 
  resolveIncident, 
  clearIncidents 
} from './services/api';

export default function App() {
  // Configuration state
  const [config, setConfig] = useState({
    photonCount: 200,
    channelLengthKm: 25,
    fiberAttenuation: 0.2,
    environmentalNoise: 0.02,
    eveEnabled: false,
    eveAttackType: 'intercept_resend',
    eveInterceptionRate: 0.5,
    qberThreshold: 0.11,
    bellThreshold: 2.0
  });

  // Telemetry metrics
  const [metrics, setMetrics] = useState({
    totalPhotons: 200,
    detectedPhotons: 165,
    siftedKeyBits: 82,
    errorBits: 2,
    qber: 0.024,
    chshS: 2.785,
    fidelity: 0.982,
    vonNeumannEntropy: 0.045,
    decoherenceRate: 0.035,
    transmissionEfficiency: 82.5
  });

  const [status, setStatus] = useState({
    classification: 'SECURE_QUANTUM_CHANNEL',
    isBreach: false,
    confidence: 99.4,
    recommendation: 'Quantum entanglement verified. CHSH violates classical limits (S = 2.785 > 2.0). Channel secure for key exchange.'
  });

  const [samplePhotons, setSamplePhotons] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [presets, setPresets] = useState([]);
  const [dbStatus, setDbStatus] = useState({ connected: false, host: 'Connecting...' });

  // Stream & Loading State
  const [isSimulating, setIsSimulating] = useState(false);
  const [isLiveStreaming, setIsLiveStreaming] = useState(false);

  // Modals
  const [isBenchmarkOpen, setIsBenchmarkOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);

  // Socket reference
  const socketRef = useRef(null);

  // Initialize data and WebSocket connection
  useEffect(() => {
    // 1. Fetch initial health & DB status
    fetchHealth().then(data => {
      if (data && data.database) {
        setDbStatus(data.database);
      }
    });

    // 2. Fetch scenario presets
    fetchPresets().then(res => {
      if (res && res.success) {
        setPresets(res.presets);
      }
    });

    // 3. Fetch incidents from DB
    fetchIncidents().then(res => {
      if (res && res.success) {
        setIncidents(res.incidents);
      }
    });

    // 4. Initial baseline simulation
    handleRunSimulation();

    // 5. Connect Socket.io
    const socket = io();
    socketRef.current = socket;

    socket.on('connect', () => {
      console.log('[WebSocket] Connected to Quantum Engine Server');
    });

    socket.on('system_status', (data) => {
      if (data && data.db) {
        setDbStatus(data.db);
      }
    });

    socket.on('photon_packet', (packet) => {
      if (packet) {
        setMetrics(packet.metrics);
        setStatus(packet.status);
        if (packet.photons && packet.photons.length > 0) {
          setSamplePhotons(prev => [...packet.photons, ...prev].slice(0, 50));
        }
      }
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  // Run single batch simulation
  const handleRunSimulation = async () => {
    setIsSimulating(true);
    try {
      const res = await runSimulation(config);
      if (res.success) {
        setMetrics(res.data.metrics);
        setStatus(res.data.status);
        setSamplePhotons(res.data.samplePhotons);

        // If an intrusion incident occurred, reload incidents
        if (res.incident) {
          fetchIncidents().then(r => {
            if (r.success) setIncidents(r.incidents);
          });
        }
      }
    } catch (err) {
      console.error('Simulation execution failed:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  // Toggle live streaming via Socket.io
  const handleToggleLiveStream = () => {
    if (!socketRef.current) return;

    if (isLiveStreaming) {
      socketRef.current.emit('stop_live_stream');
      setIsLiveStreaming(false);
    } else {
      socketRef.current.emit('start_live_stream', config);
      setIsLiveStreaming(true);
    }
  };

  // Config change handler
  const handleChangeConfig = (key, value) => {
    setConfig(prev => {
      const next = { ...prev, [key]: value };
      // If live streaming is running, update the live stream parameters
      if (isLiveStreaming && socketRef.current) {
        socketRef.current.emit('start_live_stream', next);
      }
      return next;
    });
  };

  // Select Preset Scenario
  const handleSelectPreset = (presetId) => {
    const selected = presets.find(p => p.id === presetId);
    if (selected) {
      setConfig(selected.config);
      if (isLiveStreaming && socketRef.current) {
        socketRef.current.emit('start_live_stream', selected.config);
      } else {
        runSimulation(selected.config).then(res => {
          if (res.success) {
            setMetrics(res.data.metrics);
            setStatus(res.data.status);
            setSamplePhotons(res.data.samplePhotons);
            fetchIncidents().then(r => {
              if (r.success) setIncidents(r.incidents);
            });
          }
        });
      }
    }
  };

  // Resolve incident
  const handleResolveIncident = async (id) => {
    await resolveIncident(id);
    const r = await fetchIncidents();
    if (r.success) setIncidents(r.incidents);
  };

  // Clear incidents
  const handleClearIncidents = async () => {
    await clearIncidents();
    setIncidents([]);
  };

  const handleMessageTransmitted = (res) => {
    if (res && res.data) {
      setMetrics(res.data.metrics);
      setStatus(res.data.status);
      setConfig(prev => ({
        ...prev,
        eveEnabled: res.data.evePresent,
        eveInterceptionRate: res.data.evePresent ? 0.8 : 0.0
      }));
      if (res.incident) {
        fetchIncidents().then(r => {
          if (r.success) setIncidents(r.incidents);
        });
      }
    }
  };

  const isBreach = status.isBreach;

  return (
    <div className="min-h-screen flex flex-col bg-[#05070e] text-slate-100">
      
      {/* Top Navigation */}
      <Navbar
        dbStatus={dbStatus}
        onOpenBenchmark={() => setIsBenchmarkOpen(true)}
        onOpenReport={() => setIsReportOpen(true)}
        isLiveStreaming={isLiveStreaming}
        onToggleLiveStream={handleToggleLiveStream}
        isBreach={isBreach}
      />

      {/* Main Dashboard Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        
        {/* 1. Real-time Animated Quantum Channel Canvas */}
        <section>
          <QuantumCanvas
            eveEnabled={config.eveEnabled}
            eveAttackType={config.eveAttackType}
            eveInterceptionRate={config.eveInterceptionRate}
            channelLengthKm={config.channelLengthKm}
            environmentalNoise={config.environmentalNoise}
            isBreach={isBreach}
            metrics={metrics}
            samplePhotons={samplePhotons}
          />
        </section>

        {/* 2. Key Telemetry Metrics & Status HUD */}
        <section>
          <MetricCard
            metrics={metrics}
            status={status}
            isBreach={isBreach}
          />
        </section>

        {/* 3. Controls & Configuration */}
        <section>
          <ControlPanel
            config={config}
            onChangeConfig={handleChangeConfig}
            onRunSimulation={handleRunSimulation}
            presets={presets}
            onSelectPreset={handleSelectPreset}
            isSimulating={isSimulating}
            isLiveStreaming={isLiveStreaming}
            onToggleLiveStream={handleToggleLiveStream}
          />
        </section>

        {/* 4. Blind Intrusion Test: Quantum Key Exchange & Secret Chat */}
        <section>
          <QuantumChatTransmitter
            onTransmitted={handleMessageTransmitted}
          />
        </section>

        {/* 5. Density Matrix & CHSH Bell Visualizer */}
        <section>
          <BellStateVisualizer
            metrics={metrics}
            isBreach={isBreach}
            eveEnabled={config.eveEnabled}
          />
        </section>

        {/* 5. Two Columns: Incident Log & Sifted Photon Inspector */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <IncidentLog
            incidents={incidents}
            onResolve={handleResolveIncident}
            onClear={handleClearIncidents}
            dbConnected={dbStatus.connected}
          />

          <PhotonStreamTable
            photons={samplePhotons}
          />
        </section>

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-[#060913] py-4 px-6 mt-12 text-center text-xs font-mono text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>WO-021: Quantum Entanglement-Based Intrusion Detection Visualizer</span>
          <span>Fullstack Architecture: React + Node.js + Express + MongoDB + Socket.io</span>
        </div>
      </footer>

      {/* Modals */}
      <BenchmarkModal
        isOpen={isBenchmarkOpen}
        onClose={() => setIsBenchmarkOpen(false)}
      />

      <ReportExportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        config={config}
        metrics={metrics}
        status={status}
        incidents={incidents}
      />

    </div>
  );
}
