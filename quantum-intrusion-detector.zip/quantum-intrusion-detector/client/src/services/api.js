const BASE_URL = '/api';

export const fetchHealth = async () => {
  try {
    const res = await fetch(`${BASE_URL}/health`);
    return await res.json();
  } catch (err) {
    return { status: 'OFFLINE', database: { connected: false, host: 'Unavailable' } };
  }
};

export const fetchPresets = async () => {
  const res = await fetch(`${BASE_URL}/presets`);
  return await res.json();
};

export const runSimulation = async (config) => {
  const res = await fetch(`${BASE_URL}/simulate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config)
  });
  return await res.json();
};

export const fetchHistory = async () => {
  const res = await fetch(`${BASE_URL}/simulations`);
  return await res.json();
};

export const fetchBenchmark = async (trials = 40) => {
  const res = await fetch(`${BASE_URL}/benchmark?trials=${trials}`);
  return await res.json();
};

export const fetchIncidents = async () => {
  const res = await fetch(`${BASE_URL}/incidents`);
  return await res.json();
};

export const resolveIncident = async (id) => {
  const res = await fetch(`${BASE_URL}/incidents/${id}/resolve`, {
    method: 'PATCH'
  });
  return await res.json();
};

export const clearIncidents = async () => {
  const res = await fetch(`${BASE_URL}/incidents`, {
    method: 'DELETE'
  });
  return await res.json();
};

export const transmitConfidentialMessage = async (message, mode = 'random') => {
  const res = await fetch(`${BASE_URL}/transmit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message, mode })
  });
  return await res.json();
};
