import React from 'react';
import { X, Download, Printer, ShieldCheck, ShieldAlert, FileText } from 'lucide-react';

export default function ReportExportModal({ 
  isOpen, 
  onClose, 
  config, 
  metrics, 
  status, 
  incidents 
}) {
  if (!isOpen || !metrics) return null;

  const reportData = {
    reportTitle: "Quantum Entanglement Intrusion Detection Audit Report",
    projectCode: "WO-021",
    generatedAt: new Date().toISOString(),
    systemStatus: status?.classification,
    isSecurityBreach: status?.isBreach,
    channelConfiguration: {
      channelDistanceKm: config.channelLengthKm,
      fiberAttenuationDbKm: config.fiberAttenuation || 0.2,
      environmentalNoise: config.environmentalNoise,
      eavesdropperTapped: config.eveEnabled,
      attackModel: config.eveAttackType,
      eavesdroppingProbability: config.eveInterceptionRate
    },
    quantumMetrics: {
      quantumBitErrorRate: `${(metrics.qber * 100).toFixed(2)}%`,
      qberSecurityCeiling: "11.00%",
      chshBellMetric: metrics.chshS,
      bellViolationBoundary: "S > 2.000",
      entanglementFidelity: `${(metrics.fidelity * 100).toFixed(2)}%`,
      vonNeumannEntropy: metrics.vonNeumannEntropy,
      decoherenceRate: `${(metrics.decoherenceRate * 100).toFixed(2)}%`,
      siftedKeyRate: `${metrics.siftedKeyBits} bits`
    },
    automatedMitigationRecommendation: status?.recommendation,
    incidentLogCount: incidents.length,
    recordedIncidents: incidents
  };

  const downloadJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(reportData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `quantum-audit-report-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-3xl rounded-2xl border border-cyan-500/30 bg-[#090d1a] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-[#0c1224]">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-purple-400" />
            <h3 className="text-base font-bold font-mono text-white">
              Quantum Security Audit & Intrusion Report
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Report Preview */}
        <div className="p-6 overflow-y-auto space-y-5 font-mono text-xs">
          
          {/* Header Card */}
          <div className="p-4 rounded-xl bg-[#060a16] border border-slate-800 flex justify-between items-start">
            <div>
              <div className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider">
                WO-021 PROTOCOL COMPLIANCE
              </div>
              <h2 className="text-sm font-bold text-white mt-1">
                Quantum Key Distribution (QKD) Security Assessment
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Timestamp: {new Date().toLocaleString()}
              </p>
            </div>
            <span className={`px-2.5 py-1 rounded-md text-[11px] font-bold ${
              status?.isBreach ? 'bg-red-500/20 text-red-400 border border-red-500' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500'
            }`}>
              {status?.classification}
            </span>
          </div>

          {/* Key Findings */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400">Measured QBER</span>
              <p className={`text-base font-bold mt-1 ${metrics.qber >= 0.11 ? 'text-red-400' : 'text-white'}`}>
                {(metrics.qber * 100).toFixed(2)}%
              </p>
            </div>
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400">CHSH Metric (S)</span>
              <p className={`text-base font-bold mt-1 ${metrics.chshS <= 2.0 ? 'text-red-400' : 'text-emerald-400'}`}>
                {metrics.chshS.toFixed(3)}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400">Bell Fidelity</span>
              <p className="text-base font-bold mt-1 text-purple-300">
                {(metrics.fidelity * 100).toFixed(1)}%
              </p>
            </div>
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400">Distance / Loss</span>
              <p className="text-base font-bold mt-1 text-cyan-300">
                {config.channelLengthKm}km ({(0.2 * config.channelLengthKm).toFixed(1)}dB)
              </p>
            </div>
          </div>

          {/* Recommendation Box */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
            <span className="text-[10px] text-cyan-400 font-bold uppercase">Automated Defense Recommendation:</span>
            <p className="text-slate-200 leading-relaxed text-[11px]">
              {status?.recommendation}
            </p>
          </div>

          {/* Raw JSON Snippet */}
          <div className="space-y-1">
            <span className="text-[10px] text-slate-400">Raw Telemetry Summary:</span>
            <pre className="p-3 rounded-xl bg-[#060a16] border border-slate-800 text-[10px] text-slate-400 overflow-x-auto max-h-40">
              {JSON.stringify(reportData, null, 2)}
            </pre>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-[#0c1224] flex items-center justify-between">
          <span className="text-[10px] font-mono text-slate-400">
            Export ready for compliance archiving
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={downloadJSON}
              className="px-3 py-1.5 rounded-lg text-xs font-mono font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              Download JSON
            </button>
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-lg text-xs font-mono text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / PDF
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
