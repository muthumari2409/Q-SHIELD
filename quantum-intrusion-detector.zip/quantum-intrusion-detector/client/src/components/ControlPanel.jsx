import React from 'react';
import { Settings, Play, Radio, Shield, Zap, RefreshCw, Sliders } from 'lucide-react';

export default function ControlPanel({
  config,
  onChangeConfig,
  onRunSimulation,
  presets,
  onSelectPreset,
  isSimulating,
  isLiveStreaming,
  onToggleLiveStream
}) {
  return (
    <div className="p-5 rounded-2xl border border-cyan-500/20 bg-[#090d1a] shadow-xl space-y-6">
      
      {/* Header & Presets */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold tracking-wider uppercase text-white font-mono">
            Configuration & Intrusion Engine
          </h2>
        </div>

        {/* Preset Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-mono text-slate-400">Preset:</label>
          <select
            onChange={(e) => onSelectPreset(e.target.value)}
            className="bg-slate-900 border border-slate-700 hover:border-cyan-500/50 text-slate-200 text-xs font-mono rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-cyan-400"
          >
            <option value="">-- Choose Test Scenario --</option>
            {presets.map(p => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Grid: 2 Columns (Channel Settings & Intruder Settings) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Column 1: Optical Quantum Channel */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-xs font-mono font-semibold text-cyan-400">
            <Zap className="w-3.5 h-3.5" />
            <span>OPTICAL FIBER CHANNEL</span>
          </div>

          {/* Fiber Distance */}
          <div>
            <div className="flex justify-between text-xs font-mono text-slate-300 mb-1.5">
              <span>Channel Length:</span>
              <span className="text-cyan-400 font-bold">{config.channelLengthKm} km</span>
            </div>
            <input
              type="range"
              min="2"
              max="100"
              step="1"
              value={config.channelLengthKm}
              onChange={(e) => onChangeConfig('channelLengthKm', parseFloat(e.target.value))}
              className="w-full accent-cyan-400 bg-slate-800 rounded h-1.5 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-0.5">
              <span>2 km (Metropolitan)</span>
              <span>100 km (Long-haul)</span>
            </div>
          </div>

          {/* Environmental Thermal Noise */}
          <div>
            <div className="flex justify-between text-xs font-mono text-slate-300 mb-1.5">
              <span>Thermal & Polarization Drift:</span>
              <span className="text-cyan-400 font-bold">{(config.environmentalNoise * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="0.15"
              step="0.01"
              value={config.environmentalNoise}
              onChange={(e) => onChangeConfig('environmentalNoise', parseFloat(e.target.value))}
              className="w-full accent-cyan-400 bg-slate-800 rounded h-1.5 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-0.5">
              <span>0% (Cryogenic)</span>
              <span>15% (High Noise)</span>
            </div>
          </div>

          {/* Photon Sample Batch Count */}
          <div>
            <div className="flex justify-between text-xs font-mono text-slate-300 mb-1.5">
              <span>Simulation Pulse Batch (Photons):</span>
              <span className="text-cyan-400 font-bold">{config.photonCount}</span>
            </div>
            <input
              type="range"
              min="50"
              max="1000"
              step="50"
              value={config.photonCount}
              onChange={(e) => onChangeConfig('photonCount', parseInt(e.target.value))}
              className="w-full accent-cyan-400 bg-slate-800 rounded h-1.5 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-0.5">
              <span>50 photons</span>
              <span>1,000 photons</span>
            </div>
          </div>
        </div>

        {/* Column 2: Intruder / Eavesdropper (Eve) */}
        <div className={`p-4 rounded-xl border transition-all ${
          config.eveEnabled 
            ? 'bg-red-950/20 border-red-500/40 shadow-[0_0_15px_rgba(239,68,68,0.15)]' 
            : 'bg-slate-900/40 border-slate-800'
        } space-y-4`}>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono font-semibold text-red-400">
              <Shield className="w-3.5 h-3.5" />
              <span>EVE INTRUSION INJECTOR</span>
            </div>

            {/* Eve Toggle switch */}
            <button
              onClick={() => onChangeConfig('eveEnabled', !config.eveEnabled)}
              className={`relative inline-flex h-5 w-10 items-center rounded-full transition-colors ${
                config.eveEnabled ? 'bg-red-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                  config.eveEnabled ? 'translate-x-5' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Attack Type Selector */}
          <div>
            <label className="text-xs font-mono text-slate-300 block mb-1">
              Intrusion / Attack Model:
            </label>
            <select
              disabled={!config.eveEnabled}
              value={config.eveAttackType}
              onChange={(e) => onChangeConfig('eveAttackType', e.target.value)}
              className={`w-full bg-slate-900 border text-xs font-mono rounded-lg px-2.5 py-1.5 focus:outline-none transition-all ${
                config.eveEnabled 
                  ? 'border-red-500/50 text-red-200' 
                  : 'border-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <option value="intercept_resend">1. Intercept-Resend (Classical Measurement Collapse)</option>
              <option value="beam_splitter">2. Beam Splitter Tap (Photon Number Splitting / PNS)</option>
              <option value="phase_shift">3. Quantum Phase Perturbation Gate</option>
              <option value="entanglement_swapping">4. Entanglement Swapping / State Hijack</option>
            </select>
          </div>

          {/* Eavesdropping Interception Rate Slider */}
          <div>
            <div className="flex justify-between text-xs font-mono text-slate-300 mb-1.5">
              <span>Interception Probability (Eve Tap):</span>
              <span className={`font-bold ${config.eveEnabled ? 'text-red-400' : 'text-slate-500'}`}>
                {(config.eveInterceptionRate * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="1.0"
              step="0.05"
              disabled={!config.eveEnabled}
              value={config.eveInterceptionRate}
              onChange={(e) => onChangeConfig('eveInterceptionRate', parseFloat(e.target.value))}
              className={`w-full bg-slate-800 rounded h-1.5 cursor-pointer ${
                config.eveEnabled ? 'accent-red-500' : 'accent-slate-600 opacity-50 cursor-not-allowed'
              }`}
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-0.5">
              <span>5% (Stealth Probe)</span>
              <span>100% (Full Wiretap)</span>
            </div>
          </div>
        </div>

      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center justify-end gap-3 pt-4 border-t border-slate-800">
        
        {/* Continuous Stream Button */}
        <button
          onClick={onToggleLiveStream}
          className={`px-4 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 border transition-all ${
            isLiveStreaming
              ? 'bg-red-950/80 text-red-300 border-red-500 hover:bg-red-900 shadow-[0_0_15px_rgba(239,68,68,0.4)]'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700 hover:border-cyan-500/40'
          }`}
        >
          <Radio className={`w-4 h-4 ${isLiveStreaming ? 'animate-pulse text-red-400' : 'text-cyan-400'}`} />
          {isLiveStreaming ? 'STOP CONTINUOUS STREAM' : 'START CONTINUOUS STREAM'}
        </button>

        {/* Run Single Batch Simulation Button */}
        <button
          onClick={onRunSimulation}
          disabled={isSimulating}
          className="px-5 py-2 rounded-xl text-xs font-mono font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 flex items-center gap-2 shadow-[0_0_20px_rgba(0,242,254,0.35)] transition-all disabled:opacity-50"
        >
          {isSimulating ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
              <span>SIMULATING PHOTON STATE...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-slate-950 text-slate-950" />
              <span>EXECUTE QUANTUM RUN</span>
            </>
          )}
        </button>
      </div>

    </div>
  );
}
