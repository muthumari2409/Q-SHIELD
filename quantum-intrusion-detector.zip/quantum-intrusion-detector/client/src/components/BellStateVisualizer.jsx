import React from 'react';
import { Layers, ShieldCheck, ShieldAlert, Cpu } from 'lucide-react';

export default function BellStateVisualizer({ metrics, isBreach, eveEnabled }) {
  if (!metrics) return null;

  const fidelity = metrics.fidelity;
  // Calculate density matrix components for Bell state |Phi+> under decoherence:
  // rho = F * |Phi+><Phi+| + (1-F)/4 * I_4
  const diagVal = (fidelity * 0.5 + (1 - fidelity) * 0.25).toFixed(3);
  const offDiagVal = (fidelity * 0.5).toFixed(3);
  const crossNoise = ((1 - fidelity) * 0.25).toFixed(3);

  // Density matrix 4x4 values
  const matrix = [
    [diagVal, 0, 0, offDiagVal],
    [0, crossNoise, 0, 0],
    [0, 0, crossNoise, 0],
    [offDiagVal, 0, 0, diagVal]
  ];

  const basisLabels = ['|00⟩', '|01⟩', '|10⟩', '|11⟩'];

  return (
    <div className="p-5 rounded-2xl border border-cyan-500/20 bg-[#090d1a] shadow-xl space-y-5">
      
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-purple-400" />
          <h3 className="text-sm font-bold tracking-wider uppercase text-white font-mono">
            Bell State & Density Matrix ρ
          </h3>
        </div>
        <span className="text-xs font-mono text-purple-300">
          |Φ⁺⟩ = (|00⟩ + |11⟩) / √2
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Density Matrix Visualizer Grid */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs font-mono text-slate-300">
            <span>Density Matrix Components:</span>
            <span className="text-purple-300">Fidelity: {(fidelity * 100).toFixed(1)}%</span>
          </div>

          <div className="bg-[#060a16] p-3 rounded-xl border border-slate-800">
            {/* Headers */}
            <div className="grid grid-cols-5 text-center text-[10px] font-mono text-slate-400 pb-1 border-b border-slate-800">
              <div>⟨Basis|</div>
              {basisLabels.map(l => <div key={l}>{l}</div>)}
            </div>

            {/* Matrix Rows */}
            {matrix.map((row, rIdx) => (
              <div key={rIdx} className="grid grid-cols-5 items-center text-center py-1.5 font-mono text-xs border-b border-slate-800/40">
                <div className="text-[10px] text-slate-500">{basisLabels[rIdx]}</div>
                {row.map((val, cIdx) => {
                  const num = parseFloat(val);
                  const isOffDiagCoherence = (rIdx === 0 && cIdx === 3) || (rIdx === 3 && cIdx === 0);
                  const isMainDiag = (rIdx === 0 && cIdx === 0) || (rIdx === 3 && cIdx === 3);

                  return (
                    <div 
                      key={cIdx} 
                      className={`py-1 rounded text-[11px] font-semibold transition-all ${
                        isOffDiagCoherence
                          ? num > 0.3
                            ? 'bg-purple-950/80 text-purple-300 border border-purple-500/40'
                            : 'bg-red-950/40 text-red-400 border border-red-500/30'
                          : isMainDiag
                          ? 'bg-cyan-950/60 text-cyan-300'
                          : 'text-slate-600'
                      }`}
                    >
                      {val}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          <div className="text-[10px] font-mono text-slate-400 flex items-center justify-between pt-1">
            <span className="text-purple-400">■ Off-diagonal terms = Quantum Coherence</span>
            <span className="text-red-400">Melted to ~0 = Decohered / Collapsed</span>
          </div>
        </div>

        {/* CHSH Bell Inequality Gauge & Explanation */}
        <div className="space-y-3">
          <div className="flex justify-between items-center text-xs font-mono text-slate-300">
            <span>CHSH Bell Test Gauge:</span>
            <span className={metrics.chshS > 2.0 ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
              S = {metrics.chshS.toFixed(3)}
            </span>
          </div>

          {/* Visual Scale bar */}
          <div className="relative pt-6 pb-2">
            {/* Scale Line */}
            <div className="w-full h-3 rounded-full bg-gradient-to-r from-red-600 via-amber-500 to-emerald-400 relative">
              {/* Marker for Classical Limit S = 2.0 */}
              <div 
                className="absolute top-0 bottom-0 w-1 bg-white shadow-[0_0_8px_#ffffff] z-10"
                style={{ left: `${(2.0 / 2.828) * 100}%` }}
                title="Classical Limit S = 2.0"
              />
              {/* Current Value Pointer */}
              <div 
                className="absolute -top-3 w-4 h-4 rounded-full bg-white border-2 border-slate-900 shadow-[0_0_12px_#00f2fe] transform -translate-x-1/2 transition-all duration-500 z-20"
                style={{ left: `${Math.min(100, Math.max(0, (metrics.chshS / 2.828) * 100))}%` }}
              />
            </div>

            {/* Labels */}
            <div className="flex justify-between text-[10px] font-mono text-slate-400 mt-2">
              <span>0 (Decohered)</span>
              <span className="text-white font-bold text-center">
                S = 2.0<br/>(Classical Limit)
              </span>
              <span className="text-emerald-400 font-bold text-right">
                2.828 (Max Quantum)
              </span>
            </div>
          </div>

          {/* Theoretical Summary Box */}
          <div className="p-3 rounded-xl bg-[#060a16] border border-slate-800 text-xs font-mono text-slate-300 space-y-1.5 leading-relaxed">
            <div className="flex items-center gap-1.5 text-cyan-300 font-semibold text-[11px]">
              <Cpu className="w-3.5 h-3.5" />
              <span>THEORETICAL QUANTUM SIGNATURE</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {metrics.chshS > 2.0 ? (
                <span className="text-emerald-300">
                  ✔ Bell's Inequality Violated (S = {metrics.chshS.toFixed(3)} &gt; 2.0). Quantum non-locality holds. No eavesdropper has performed projective measurement.
                </span>
              ) : (
                <span className="text-red-300">
                  ✖ Bell's Inequality Satisfied (S = {metrics.chshS.toFixed(3)} ≤ 2.0). Quantum entanglement broken. State has reverted to classical local realism due to observer interaction!
                </span>
              )}
            </p>
          </div>

        </div>

      </div>

    </div>
  );
}
