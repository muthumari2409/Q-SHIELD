import React, { useRef, useEffect, useState } from 'react';
import { Play, Pause, FastForward, RotateCcw, Zap, Lock, Unlock } from 'lucide-react';

export default function QuantumCanvas({
  eveEnabled,
  eveAttackType,
  eveInterceptionRate,
  channelLengthKm,
  environmentalNoise,
  isBreach,
  metrics,
  samplePhotons
}) {
  const canvasRef = useRef(null);
  const [isRunning, setIsRunning] = useState(true);
  const [speed, setSpeed] = useState(1);

  // Particles moving through the quantum channel
  const particlesRef = useRef([]);
  const animFrameIdRef = useRef(null);
  const lastSpawnTimeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    // Handle high-DPI & responsive canvas resizing
    const updateCanvasSize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
    };

    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);

    const render = (time) => {
      const dpr = window.devicePixelRatio || 1;
      const width = canvas.width / dpr;
      const height = canvas.height / dpr;

      ctx.save();
      ctx.scale(dpr, dpr);

      // Clear background
      ctx.fillStyle = '#060a16';
      ctx.fillRect(0, 0, width, height);

      // Channel Layout Positions
      const nodeWidth = 120;
      const nodeHeight = 110;
      const marginX = 24;
      const midY = height / 2;

      const aliceX = marginX;
      const bobX = width - marginX - nodeWidth;

      const startX = aliceX + nodeWidth;
      const endX = bobX;
      const eveX = startX + (endX - startX) * 0.5;

      // 1. Draw Fiber Optic Core Cable
      const channelGrad = ctx.createLinearGradient(startX, 0, endX, 0);
      if (isBreach) {
        channelGrad.addColorStop(0, 'rgba(0, 242, 254, 0.4)');
        channelGrad.addColorStop(0.45, 'rgba(239, 68, 68, 0.85)');
        channelGrad.addColorStop(1, 'rgba(239, 68, 68, 0.4)');
      } else {
        channelGrad.addColorStop(0, 'rgba(0, 242, 254, 0.35)');
        channelGrad.addColorStop(0.5, 'rgba(168, 85, 247, 0.5)');
        channelGrad.addColorStop(1, 'rgba(0, 242, 254, 0.35)');
      }

      ctx.save();
      ctx.strokeStyle = channelGrad;
      ctx.lineWidth = 12;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(startX, midY);
      ctx.lineTo(endX, midY);
      ctx.stroke();

      // Optical core inner light line
      ctx.strokeStyle = isBreach ? '#fca5a5' : '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();

      // Fiber distance kilometer markers
      ctx.fillStyle = '#64748b';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      for (let mark = 0.25; mark < 1; mark += 0.25) {
        const mx = startX + (endX - startX) * mark;
        ctx.fillRect(mx, midY - 8, 1, 16);
        ctx.fillText(`${(channelLengthKm * mark).toFixed(0)} km`, mx, midY + 24);
      }

      // 2. Draw Alice Transmitter Node
      ctx.save();
      ctx.fillStyle = '#0b1120';
      ctx.strokeStyle = '#00f2fe';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(aliceX, midY - nodeHeight / 2, nodeWidth, nodeHeight, 10);
      ctx.fill();
      ctx.stroke();

      // Alice Text Info
      ctx.textAlign = 'left';
      ctx.fillStyle = '#00f2fe';
      ctx.font = 'bold 12px "JetBrains Mono", monospace';
      ctx.fillText('ALICE (TX)', aliceX + 14, midY - 26);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.fillText('SPDC Crystal', aliceX + 14, midY - 6);
      ctx.fillText('Bell |Φ⁺⟩ Gen', aliceX + 14, midY + 12);
      ctx.fillText('λ = 1550 nm', aliceX + 14, midY + 30);

      // Transmitter output diode
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(aliceX + nodeWidth - 6, midY, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#bae6fd';
      ctx.stroke();
      ctx.restore();

      // 3. Draw Bob Receiver Node
      ctx.save();
      ctx.fillStyle = '#0b1120';
      ctx.strokeStyle = isBreach ? '#ef4444' : '#10b981';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(bobX, midY - nodeHeight / 2, nodeWidth, nodeHeight, 10);
      ctx.fill();
      ctx.stroke();

      ctx.textAlign = 'left';
      ctx.fillStyle = isBreach ? '#ef4444' : '#10b981';
      ctx.font = 'bold 12px "JetBrains Mono", monospace';
      ctx.fillText('BOB (RX)', bobX + 14, midY - 26);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.fillText('Polarizer 0°/45°', bobX + 14, midY - 6);
      ctx.fillText('SPAD Detector', bobX + 14, midY + 12);
      ctx.fillText('Basis Sifting', bobX + 14, midY + 30);

      // Receiver input lens
      ctx.fillStyle = isBreach ? '#f87171' : '#34d399';
      ctx.beginPath();
      ctx.arc(bobX + 6, midY, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();
      ctx.restore();

      // 4. Draw Eve Eavesdropper Probe (Center)
      ctx.save();
      const eveActive = eveEnabled && eveInterceptionRate > 0;
      const eveBoxW = 130;
      const eveBoxH = 46;

      ctx.fillStyle = eveActive ? '#1e1124' : '#0f172a';
      ctx.strokeStyle = eveActive ? '#ef4444' : '#475569';
      ctx.lineWidth = eveActive ? 2 : 1;
      ctx.setLineDash(eveActive ? [] : [4, 4]);
      ctx.beginPath();
      ctx.roundRect(eveX - eveBoxW / 2, midY - 105, eveBoxW, eveBoxH, 8);
      ctx.fill();
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.textAlign = 'center';
      ctx.fillStyle = eveActive ? '#ef4444' : '#64748b';
      ctx.font = 'bold 11px "JetBrains Mono", monospace';
      ctx.fillText(eveActive ? '⚡ EVE INTERCEPT' : 'NO INTRUSION', eveX, midY - 86);

      ctx.font = '9px "JetBrains Mono", monospace';
      ctx.fillStyle = eveActive ? '#fca5a5' : '#475569';
      ctx.fillText(eveActive ? `${(eveInterceptionRate * 100).toFixed(0)}% Rate: ${eveAttackType}` : 'Fiber line secure', eveX, midY - 70);

      // Probe needle connecting to fiber
      ctx.strokeStyle = eveActive ? '#ef4444' : '#475569';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(eveX, midY - (105 - eveBoxH));
      ctx.lineTo(eveX, midY - 8);
      ctx.stroke();

      if (eveActive) {
        // Tapping pulse indicator ring
        const pulseRadius = 12 + Math.sin(time * 0.008) * 4;
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(eveX, midY, pulseRadius, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();

      // 5. Spawn Entangled Photon Wavepackets
      if (isRunning && time - lastSpawnTimeRef.current > 420 / speed) {
        lastSpawnTimeRef.current = time;
        const willBeIntercepted = eveActive && Math.random() < eveInterceptionRate;
        const willHaveNoise = Math.random() < environmentalNoise;
        particlesRef.current.push({
          id: Math.random(),
          x: startX + 4,
          y: midY,
          phase: 0,
          isIntercepted: willBeIntercepted,
          hasDecohered: false,
          hasNoise: willHaveNoise,
          decayDispersal: 0
        });
      }

      // 6. Draw each Photon Wavepacket
      const updatedParticles = [];
      particlesRef.current.forEach(p => {
        p.x += 2.6 * speed;
        p.phase += 0.22;

        // Check if passing Eve's intercept probe
        if (p.x >= eveX && p.isIntercepted && !p.hasDecohered) {
          p.hasDecohered = true;
        }

        ctx.save();
        if (!p.hasDecohered) {
          // Pure Entangled Bell Pair: Coherent twin glowing wavepacket
          const waveAmp = 6;
          const waveY = midY + Math.sin(p.phase) * waveAmp;

          // Glowing aura
          const grad = ctx.createRadialGradient(p.x, waveY, 1, p.x, waveY, 14);
          grad.addColorStop(0, 'rgba(0, 242, 254, 1)');
          grad.addColorStop(0.5, 'rgba(168, 85, 247, 0.7)');
          grad.addColorStop(1, 'rgba(0, 242, 254, 0)');

          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(p.x, waveY, 12, 0, Math.PI * 2);
          ctx.fill();

          // Photon core
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(p.x, waveY, 3.5, 0, Math.PI * 2);
          ctx.fill();

          // Entangled twin particle
          const twinY = midY - Math.sin(p.phase) * waveAmp;
          ctx.fillStyle = '#00f2fe';
          ctx.beginPath();
          ctx.arc(p.x - 7, twinY, 2.5, 0, Math.PI * 2);
          ctx.fill();

          // Entanglement bond
          ctx.strokeStyle = 'rgba(0, 242, 254, 0.6)';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(p.x, waveY);
          ctx.lineTo(p.x - 7, twinY);
          ctx.stroke();

        } else {
          // Wavefunction Collapsed: Red decohered scattered particles
          p.decayDispersal += 0.25;
          const scatterAmp = Math.min(22, 4 + p.decayDispersal * 2);

          ctx.fillStyle = 'rgba(239, 68, 68, 0.25)';
          ctx.beginPath();
          ctx.arc(p.x, midY, scatterAmp + 4, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#ef4444';
          ctx.beginPath();
          ctx.arc(p.x, midY + Math.sin(p.phase * 2) * scatterAmp, 3, 0, Math.PI * 2);
          ctx.arc(p.x - 6, midY - Math.cos(p.phase * 2) * (scatterAmp * 0.8), 2.5, 0, Math.PI * 2);
          ctx.arc(p.x - 12, midY + Math.sin(p.phase * 3) * (scatterAmp * 0.5), 2, 0, Math.PI * 2);
          ctx.fill();

          ctx.font = '8px "JetBrains Mono", monospace';
          ctx.fillStyle = '#f87171';
          ctx.textAlign = 'center';
          ctx.fillText('COLLAPSE', p.x, midY - scatterAmp - 6);
        }
        ctx.restore();

        // Keep particle if not reached Bob yet
        if (p.x < endX - 4) {
          updatedParticles.push(p);
        }
      });

      particlesRef.current = updatedParticles;
      ctx.restore();

      animFrameIdRef.current = requestAnimationFrame(render);
    };

    animFrameIdRef.current = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', updateCanvasSize);
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
    };
  }, [isRunning, speed, eveEnabled, eveAttackType, eveInterceptionRate, channelLengthKm, environmentalNoise, isBreach]);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-cyan-500/20 bg-[#060a16] shadow-2xl">
      {/* Top Banner overlay */}
      <div className="absolute top-3 left-4 right-4 flex items-center justify-between z-10 pointer-events-none">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900/80 border border-slate-700/80 text-[11px] font-mono text-cyan-300">
            <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>REAL-TIME CHANNEL WAVEFUNCTIONS</span>
          </div>
          {isBreach ? (
            <span className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-red-950/80 border border-red-500/50 text-[11px] font-mono text-red-300 animate-pulse">
              <Unlock className="w-3.5 h-3.5" /> DECOHERENCE DETECTED
            </span>
          ) : (
            <span className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-950/80 border border-emerald-500/40 text-[11px] font-mono text-emerald-300">
              <Lock className="w-3.5 h-3.5" /> BELL ENTANGLEMENT INTACT
            </span>
          )}
        </div>

        {/* Legend */}
        <div className="hidden md:flex items-center gap-4 px-3 py-1 rounded-md bg-slate-900/80 border border-slate-700/80 text-[10px] font-mono text-slate-300">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_6px_#00f2fe]" />
            <span>Coherent Bell Pair</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_6px_#ef4444]" />
            <span>Wavefunction Collapse</span>
          </div>
        </div>
      </div>

      {/* Canvas */}
      <canvas
        ref={canvasRef}
        className="w-full h-64 md:h-72 block cursor-crosshair"
      />

      {/* Bottom Floating Canvas Controls */}
      <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className="p-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:border-cyan-500/50 transition-all"
            title={isRunning ? 'Pause Animation' : 'Resume Animation'}
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 text-cyan-400" />}
          </button>
          
          <button
            onClick={() => setSpeed(s => s === 1 ? 2 : s === 2 ? 0.5 : 1)}
            className="px-2 py-1 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 text-xs font-mono border border-slate-700 flex items-center gap-1 transition-all"
            title="Adjust Simulation Speed"
          >
            <FastForward className="w-3 h-3 text-cyan-400" />
            <span>{speed}x</span>
          </button>

          <button
            onClick={() => { particlesRef.current = []; }}
            className="p-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
            title="Clear Stream"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="text-[11px] font-mono text-slate-400 bg-slate-900/80 px-2.5 py-1 rounded border border-slate-800">
          Channel Loss: <span className="text-cyan-400 font-semibold">{(0.2 * channelLengthKm).toFixed(1)} dB</span> | Distance: <span className="text-white font-semibold">{channelLengthKm} km</span>
        </div>
      </div>
    </div>
  );
}
