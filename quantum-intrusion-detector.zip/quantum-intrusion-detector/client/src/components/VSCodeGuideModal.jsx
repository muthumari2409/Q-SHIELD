import React, { useState } from 'react';
import { X, Code2, Database, Terminal, CheckCircle2, Copy, Check } from 'lucide-react';

export default function VSCodeGuideModal({ isOpen, onClose }) {
  const [copiedIndex, setCopiedIndex] = useState(null);

  if (!isOpen) return null;

  const copyToClipboard = (text, index) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const steps = [
    {
      title: "1. Open in Visual Studio Code",
      cmd: `cd "C:\\Users\\Muthumari\\.gemini\\antigravity\\scratch\\quantum-intrusion-detector"\ncode .`,
      desc: "Open your terminal or PowerShell and run this command to launch the entire project folder directly inside VS Code."
    },
    {
      title: "2. Connect MongoDB (Database)",
      cmd: `# Option A: Local MongoDB (Default)\n# Start your local mongod service:\nmongod\n\n# Option B: MongoDB Atlas (Cloud Free Cluster)\n# In server/.env, set your connection string:\nMONGODB_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/quantum_ids?retryWrites=true&w=majority`,
      desc: "MongoDB use pannalam! Both Local MongoDB and Cloud MongoDB Atlas are 100% supported. If MongoDB is not yet started, the server uses an automatic In-Memory fallback so it never crashes."
    },
    {
      title: "3. Run Backend (Terminal 1 in VS Code)",
      cmd: `cd server\nnpm run dev`,
      desc: "Starts the Express API and Socket.io server on http://localhost:5000 with auto-restart on changes."
    },
    {
      title: "4. Run Frontend Visualizer (Terminal 2 in VS Code)",
      cmd: `cd client\nnpm run dev`,
      desc: "Launches the high-tech Vite React Dashboard on http://localhost:3000."
    },
    {
      title: "5. One-Click Launch with VS Code F5",
      cmd: `Press F5 in VS Code`,
      desc: "Pre-configured .vscode/launch.json and tasks.json allow you to launch both Backend and Frontend simultaneously with a single press of F5!"
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-3xl rounded-2xl border border-cyan-500/30 bg-[#090d1a] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-[#0c1224]">
          <div className="flex items-center gap-2">
            <Code2 className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold font-mono text-white">
              VS Code & MongoDB Setup Guide (Tamil / English)
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 font-mono text-xs">
          
          <div className="p-4 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-cyan-300 leading-relaxed">
            <p className="font-semibold text-sm mb-1 text-white">
              Welcome! Intha project-ah VS Code and MongoDB kooda connect panni run panna steps:
            </p>
            <p className="text-[11px] text-cyan-200">
              Follow these simple steps below. Backend and Frontend already have full dependencies installed!
            </p>
          </div>

          <div className="space-y-4">
            {steps.map((s, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-[#060a16] border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                    {s.title}
                  </span>
                  <button
                    onClick={() => copyToClipboard(s.cmd, idx)}
                    className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] flex items-center gap-1 transition-colors"
                    title="Copy command"
                  >
                    {copiedIndex === idx ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  {s.desc}
                </p>

                <pre className="p-3 rounded-lg bg-black/60 border border-slate-800 text-[11px] text-cyan-300 overflow-x-auto whitespace-pre-wrap">
                  {s.cmd}
                </pre>
              </div>
            ))}
          </div>

          {/* MongoDB Connection Details */}
          <div className="p-4 rounded-xl bg-purple-950/30 border border-purple-500/40 space-y-2">
            <div className="flex items-center gap-2 text-purple-300 font-bold text-xs">
              <Database className="w-4 h-4" />
              <span>MongoDB Configuration Notes:</span>
            </div>
            <ul className="list-disc list-inside text-slate-300 text-[11px] space-y-1 leading-relaxed">
              <li><strong>Can we use MongoDB?</strong> Yes, absolutely! Models for <code className="text-purple-300">SimulationRun</code> and <code className="text-purple-300">IntrusionIncident</code> are fully implemented with Mongoose.</li>
              <li>Configure your connection string in <code className="text-cyan-300">server/.env</code>: <code className="text-purple-300">MONGODB_URI=...</code></li>
              <li>Even if MongoDB is temporarily turned off or not installed on your PC, the app continues to function seamlessly with in-memory caching and will automatically persist once MongoDB is started!</li>
            </ul>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-[#0c1224] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-mono text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors"
          >
            Got it
          </button>
        </div>

      </div>
    </div>
  );
}
