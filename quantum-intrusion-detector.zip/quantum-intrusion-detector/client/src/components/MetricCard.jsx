import React from 'react';
import { ShieldCheck, ShieldAlert, Activity, Gauge, Flame, AlertTriangle } from 'lucide-react';

export default function MetricCard({ metrics, status, isBreach }) {
  if (!metrics) return null;

  const qberPercent = (metrics.qber * 100).toFixed(2);
  const qberExceeded = metrics.qber >= 0.11;
  const bellViolated = metrics.chshS > 2.0;

  return (
    <div className="space-y-4">
      {/* Primary Security Alert Banner */}
      <div className={`p-4 rounded-xl border transition-all duration-300 ${
        isBreach
          ? 'bg-red-950/40 border-red-500/60 shadow-[0_0_20px_rgba(239,68,68,0.3)]'
          : status?.classification === 'ENVIRONMENTAL_NOISE'
          ? 'bg-amber-950/40 border-amber-500/60'
          : 'bg-emerald-950/30 border-emerald-500/40 shadow-[0_0_20px_rgba(16,185,129,0.15)]'
      }`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className={`p-2.5 rounded-lg border mt-0.5 ${
              isBreach 
                ? 'bg-red-500/20 border-red-500 text-red-400' 
                : 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
            }`}>
              {isBreach ? <ShieldAlert className="w-6 h-6 animate-pulse" /> : <ShieldCheck className="w-6 h-6" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold tracking-wider ${
                  isBreach 
                    ? 'bg-red-500 text-white' 
                    : status?.classification === 'ENVIRONMENTAL_NOISE'
                    ? 'bg-amber-500 text-black'
                    : 'bg-emerald-500 text-black'
                }`}>
                  {status?.classification?.replace(/_/g, ' ') || 'ACTIVE'}
                </span>
                <span className="text-xs font-mono text-slate-400">
                  Confidence: {status?.confidence || 99}%
                </span>
              </div>
              <p className="text-xs md:text-sm text-slate-200 mt-1.5 font-medium leading-relaxed">
                {status?.recommendation}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of Key Quantum Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        
        {/* 1. QBER (Quantum Bit Error Rate) */}
        <div className={`p-4 rounded-xl border transition-all ${
          qberExceeded 
            ? 'bg-red-950/20 border-red-500/50 shadow-[0_0_15px_rgba(239,68,68,0.2)]' 
            : 'bg-[#0b101f] border-slate-800 hover:border-cyan-500/40'
        }`}>
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-2">
            <span>QBER (Bit Error)</span>
            <Activity className={`w-4 h-4 ${qberExceeded ? 'text-red-400 animate-pulse' : 'text-cyan-400'}`} />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className={`text-2xl font-bold font-mono ${qberExceeded ? 'text-red-400' : 'text-white'}`}>
              {qberPercent}%
            </span>
            <span className="text-[10px] font-mono text-slate-500">
              limit: 11.0%
            </span>
          </div>
          {/* Progress bar */}
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${
                qberExceeded ? 'bg-red-500' : 'bg-cyan-400'
              }`}
              style={{ width: `${Math.min(100, (metrics.qber / 0.25) * 100)}%` }}
            />
          </div>
          <div className="text-[10px] font-mono text-slate-400 mt-1 flex justify-between">
            <span>0% (Ideal)</span>
            <span className="text-red-400 font-bold">11% (Ceiling)</span>
          </div>
        </div>

        {/* 2. CHSH Bell Parameter S */}
        <div className={`p-4 rounded-xl border transition-all ${
          !bellViolated 
            ? 'bg-red-950/20 border-red-500/50 shadow-[0_0_15px_rgba(239,68,68,0.2)]' 
            : 'bg-[#0b101f] border-slate-800 hover:border-cyan-500/40'
        }`}>
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-2">
            <span>CHSH Bell Metric (S)</span>
            <Gauge className={`w-4 h-4 ${bellViolated ? 'text-emerald-400' : 'text-red-400 animate-pulse'}`} />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className={`text-2xl font-bold font-mono ${bellViolated ? 'text-emerald-400' : 'text-red-400'}`}>
              {metrics.chshS.toFixed(3)}
            </span>
            <span className="text-[10px] font-mono text-slate-500">
              bound: S &gt; 2.0
            </span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${
                bellViolated ? 'bg-emerald-400' : 'bg-red-500'
              }`}
              style={{ width: `${Math.min(100, (metrics.chshS / 2.828) * 100)}%` }}
            />
          </div>
          <div className="text-[10px] font-mono text-slate-400 mt-1 flex justify-between">
            <span>S ≤ 2 (Classical)</span>
            <span className="text-emerald-400 font-bold">2.828 (Cirel'son)</span>
          </div>
        </div>

        {/* 3. Entanglement Fidelity */}
        <div className="p-4 rounded-xl border bg-[#0b101f] border-slate-800 hover:border-cyan-500/40 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-2">
            <span>State Fidelity (F)</span>
            <Flame className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-purple-300">
              {(metrics.fidelity * 100).toFixed(1)}%
            </span>
            <span className="text-[10px] font-mono text-slate-500">
              |⟨Φ⁺|ρ|Φ⁺⟩|
            </span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div 
              className="h-full rounded-full bg-gradient-to-r from-purple-500 to-cyan-400 transition-all duration-500"
              style={{ width: `${metrics.fidelity * 100}%` }}
            />
          </div>
          <div className="text-[10px] font-mono text-slate-400 mt-1 flex justify-between">
            <span>Mixed State</span>
            <span>Pure Bell State</span>
          </div>
        </div>

        {/* 4. Von Neumann Entropy & Transmission */}
        <div className="p-4 rounded-xl border bg-[#0b101f] border-slate-800 hover:border-cyan-500/40 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono mb-2">
            <span>Von Neumann Entropy</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-amber-300">
              {metrics.vonNeumannEntropy.toFixed(3)}
            </span>
            <span className="text-[10px] font-mono text-slate-500">
              S(ρ) [0 - 2.0]
            </span>
          </div>
          <div className="text-[11px] font-mono text-slate-300 mt-3 pt-2 border-t border-slate-800 flex justify-between">
            <span>Efficiency:</span>
            <span className="text-cyan-400 font-semibold">{metrics.transmissionEfficiency}%</span>
          </div>
          <div className="text-[11px] font-mono text-slate-300 flex justify-between">
            <span>Key Sifted:</span>
            <span className="text-white font-semibold">{metrics.siftedKeyBits} / {metrics.totalPhotons}</span>
          </div>
        </div>

      </div>
    </div>
  );
}
