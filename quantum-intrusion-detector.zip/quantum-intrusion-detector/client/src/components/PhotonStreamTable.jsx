import React from 'react';
import { Eye, CheckCircle2, XCircle, Zap } from 'lucide-react';

export default function PhotonStreamTable({ photons }) {
  if (!photons || photons.length === 0) {
    return (
      <div className="p-6 rounded-2xl border border-slate-800 bg-[#090d1a] text-center font-mono text-xs text-slate-500">
        Run simulation or start live stream to inspect individual photon packets.
      </div>
    );
  }

  return (
    <div className="p-5 rounded-2xl border border-cyan-500/20 bg-[#090d1a] shadow-xl space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-bold tracking-wider uppercase text-white font-mono">
            Sifted Key Photon Stream Inspector ({photons.length} Sampled)
          </h3>
        </div>
        <span className="text-xs font-mono text-slate-400">
          E91 / BB84 Sifted Subspace
        </span>
      </div>

      <div className="overflow-x-auto max-h-72 overflow-y-auto">
        <table className="w-full text-left font-mono text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-[11px] text-slate-400 bg-slate-900/50">
              <th className="py-2.5 px-3">Photon #</th>
              <th className="py-2.5 px-3">Alice Basis</th>
              <th className="py-2.5 px-3">Alice Bit</th>
              <th className="py-2.5 px-3">Bob Basis</th>
              <th className="py-2.5 px-3">Bob Bit</th>
              <th className="py-2.5 px-3">Eve Tap?</th>
              <th className="py-2.5 px-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {photons.slice(0, 30).map((p, idx) => {
              const isError = p.bitError;
              const isIntercepted = p.eveInterception;

              return (
                <tr 
                  key={idx} 
                  className={`hover:bg-slate-800/40 transition-colors ${
                    isError ? 'bg-red-950/20' : ''
                  }`}
                >
                  <td className="py-2 px-3 text-slate-400 font-semibold">#{p.index || idx + 1}</td>
                  
                  {/* Alice Basis & Bit */}
                  <td className="py-2 px-3">
                    <span className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 text-[10px]">
                      {p.aliceBasis === '+' ? 'Rectilinear (+)' : 'Diagonal (x)'}
                    </span>
                  </td>
                  <td className="py-2 px-3 font-bold text-white">{p.aliceBit}</td>

                  {/* Bob Basis & Bit */}
                  <td className="py-2 px-3">
                    <span className="px-1.5 py-0.5 rounded bg-purple-950 text-purple-400 border border-purple-800 text-[10px]">
                      {p.bobBasis === '+' ? 'Rectilinear (+)' : 'Diagonal (x)'}
                    </span>
                  </td>
                  <td className="py-2 px-3 font-bold text-white">{p.bobBit}</td>

                  {/* Eve Tap Status */}
                  <td className="py-2 px-3">
                    {isIntercepted ? (
                      <span className="inline-flex items-center gap-1 text-red-400 font-semibold text-[11px]">
                        <Eye className="w-3.5 h-3.5" /> Intercepted
                      </span>
                    ) : (
                      <span className="text-slate-500 text-[11px]">Clean</span>
                    )}
                  </td>

                  {/* Outcome */}
                  <td className="py-2 px-3">
                    {isError ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-400 border border-red-500/40">
                        <XCircle className="w-3 h-3" /> BIT ERROR
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                        <CheckCircle2 className="w-3 h-3" /> MATCHED
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
