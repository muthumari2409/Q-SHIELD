import React, { useState } from 'react';
import { X, Play, RefreshCw, BarChart2, CheckCircle2, AlertTriangle } from 'lucide-react';
import { fetchBenchmark } from '../services/api';

export default function BenchmarkModal({ isOpen, onClose }) {
  const [loading, setLoading] = useState(false);
  const [benchmarkData, setBenchmarkData] = useState(null);
  const [trials, setTrials] = useState(40);

  if (!isOpen) return null;

  const handleRunBenchmark = async () => {
    setLoading(true);
    try {
      const res = await fetchBenchmark(trials);
      if (res.success) {
        setBenchmarkData(res.benchmark);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-3xl rounded-2xl border border-cyan-500/30 bg-[#090d1a] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-[#0c1224]">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold font-mono text-white">
              Monte Carlo Statistical Evaluation Benchmark
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          <p className="text-xs font-mono text-slate-300 leading-relaxed">
            Runs repeated Monte Carlo trials across varying eavesdropping probabilities (0% to 100%) to measure intrusion detection sensitivity, CHSH correlation degradation, and false positive rates.
          </p>

          {/* Controls */}
          <div className="flex flex-wrap items-center gap-4 p-4 rounded-xl bg-[#060a16] border border-slate-800">
            <div className="flex items-center gap-2">
              <label className="text-xs font-mono text-slate-400">Trials per evaluation point:</label>
              <select
                value={trials}
                onChange={(e) => setTrials(parseInt(e.target.value))}
                className="bg-slate-900 border border-slate-700 text-xs font-mono text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-cyan-400"
              >
                <option value={20}>20 trials (Fast)</option>
                <option value={50}>50 trials (Balanced)</option>
                <option value={100}>100 trials (High Precision)</option>
              </select>
            </div>

            <button
              onClick={handleRunBenchmark}
              disabled={loading}
              className="px-4 py-2 rounded-xl text-xs font-mono font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 flex items-center gap-2 shadow-[0_0_15px_rgba(0,242,254,0.3)] transition-all disabled:opacity-50"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Computing Monte Carlo Trials...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-slate-950" />
                  <span>Run Benchmark Evaluation</span>
                </>
              )}
            </button>
          </div>

          {/* Results Table */}
          {benchmarkData && (
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs font-mono text-slate-300">
                <span className="font-semibold text-cyan-400">Benchmark Results ({benchmarkData.trialsPerPoint} trials/pt):</span>
                <span className="text-slate-500">{new Date(benchmarkData.benchmarkTimestamp).toLocaleTimeString()}</span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left font-mono text-xs">
                  <thead className="bg-slate-900/80 text-slate-400 text-[11px] border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-3">Eve Tap Rate</th>
                      <th className="py-2.5 px-3">Avg QBER</th>
                      <th className="py-2.5 px-3">CHSH Metric (S)</th>
                      <th className="py-2.5 px-3">Fidelity</th>
                      <th className="py-2.5 px-3">Detection Rate</th>
                      <th className="py-2.5 px-3">Bell Boundary</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 bg-[#060a16]">
                    {benchmarkData.results.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/40">
                        <td className="py-2 px-3 font-bold text-white">{(row.eavesdropRate * 100).toFixed(0)}%</td>
                        <td className={`py-2 px-3 font-semibold ${row.avgQber > 11 ? 'text-red-400' : 'text-slate-300'}`}>
                          {row.avgQber}%
                        </td>
                        <td className={`py-2 px-3 font-semibold ${row.avgChsh > 2.0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {row.avgChsh}
                        </td>
                        <td className="py-2 px-3 text-purple-300">{(row.avgFidelity * 100).toFixed(1)}%</td>
                        <td className="py-2 px-3 font-bold text-cyan-300">{row.detectionRate}%</td>
                        <td className="py-2 px-3">
                          {row.bellViolation ? (
                            <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400">
                              <CheckCircle2 className="w-3 h-3" /> Entangled (S &gt; 2)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[10px] text-red-400">
                              <AlertTriangle className="w-3 h-3" /> Classical (S ≤ 2)
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-[#0c1224] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-mono text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}
