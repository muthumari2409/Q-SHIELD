import React from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Database, 
  Activity, 
  BarChart3, 
  FileDown, 
  Code2, 
  Radio, 
  Sparkles 
} from 'lucide-react';

export default function Navbar({ 
  dbStatus, 
  onOpenBenchmark, 
  onOpenReport, 
  isLiveStreaming,
  onToggleLiveStream,
  isBreach
}) {
  return (
    <header className={`sticky top-0 z-40 w-full border-b transition-colors duration-500 ${
      isBreach ? 'border-red-500/40 bg-[#090b14]/95' : 'border-cyan-500/20 bg-[#060913]/90'
    } backdrop-blur-md px-4 py-3 shadow-lg`}>
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Brand & Project Info */}
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl border flex items-center justify-center transition-all duration-300 ${
            isBreach 
              ? 'bg-red-500/20 border-red-500 text-red-400 shadow-[0_0_15px_rgba(239,68,68,0.5)]' 
              : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400 shadow-[0_0_15px_rgba(0,242,254,0.25)]'
          }`}>
            {isBreach ? <ShieldAlert className="w-6 h-6 animate-pulse" /> : <ShieldCheck className="w-6 h-6" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold tracking-wider bg-cyan-950 text-cyan-400 border border-cyan-800">
                WO-021
              </span>
              <span className="px-2 py-0.5 rounded text-xs font-mono font-bold tracking-wider bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950">
                Q-SHIELD
              </span>
              <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
                Quantum Intrusion Detection Visualizer
              </h1>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Bell-State Decoherence & E91 Protocol Security Monitor
            </p>
          </div>
        </div>

        {/* Status Indicators & Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          
          {/* Live Streaming Indicator Button */}
          <button
            onClick={onToggleLiveStream}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 border transition-all ${
              isLiveStreaming 
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-[0_0_12px_rgba(16,185,129,0.3)] animate-pulse'
                : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:border-cyan-500/50'
            }`}
          >
            <Radio className={`w-3.5 h-3.5 ${isLiveStreaming ? 'text-emerald-400' : 'text-slate-400'}`} />
            {isLiveStreaming ? 'LIVE STREAMING' : 'START STREAM'}
          </button>

          {/* MongoDB Connection Status Pill */}
          <div 
            title={dbStatus?.connected ? `Connected to ${dbStatus.host}` : 'Running with In-Memory fallback (MongoDB offline)'}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-mono flex items-center gap-1.5 border ${
              dbStatus?.connected 
                ? 'bg-emerald-950/60 text-emerald-400 border-emerald-500/40' 
                : 'bg-amber-950/50 text-amber-300 border-amber-500/40'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>MongoDB: {dbStatus?.connected ? 'ONLINE' : 'FALLBACK'}</span>
          </div>

          {/* Benchmark Suite */}
          <button
            onClick={onOpenBenchmark}
            className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-200 bg-slate-800/90 hover:bg-slate-700/80 border border-slate-700 hover:border-cyan-500/40 flex items-center gap-1.5 transition-all"
          >
            <BarChart3 className="w-3.5 h-3.5 text-cyan-400" />
            Benchmark
          </button>

          {/* Export Report */}
          <button
            onClick={onOpenReport}
            className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-200 bg-slate-800/90 hover:bg-slate-700/80 border border-slate-700 hover:border-cyan-500/40 flex items-center gap-1.5 transition-all"
          >
            <FileDown className="w-3.5 h-3.5 text-purple-400" />
            Export Audit
          </button>
        </div>

      </div>
    </header>
  );
}
