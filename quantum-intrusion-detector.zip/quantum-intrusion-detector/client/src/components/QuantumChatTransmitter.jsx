import React, { useState } from 'react';
import { Send, KeyRound, ShieldAlert, ShieldCheck, Lock, Unlock, HelpCircle, Sparkles, RefreshCw } from 'lucide-react';
import { transmitConfidentialMessage } from '../services/api';

export default function QuantumChatTransmitter({ onTransmitted }) {
  const [message, setMessage] = useState('BANK-TRANSFER-$50,000');
  const [testMode, setTestMode] = useState('random'); // 'random', 'clean', 'eavesdrop'
  const [transmitting, setTransmitting] = useState(false);
  const [result, setResult] = useState(null);

  const presets = [
    'BANK-TRANSFER-$50,000',
    'LAUNCH-CODE: 994-ALPHA',
    'CONFIDENTIAL-AUTH-TOKEN-771',
    'DEFENSE-LOCATION: 12.97N, 77.59E'
  ];

  const handleTransmit = async () => {
    if (!message.trim()) return;
    setTransmitting(true);
    setResult(null);

    try {
      const res = await transmitConfidentialMessage(message, testMode);
      if (res.success) {
        setResult(res.data);
        if (onTransmitted) {
          onTransmitted(res);
        }
      }
    } catch (err) {
      console.error('Transmission failed:', err);
    } finally {
      setTransmitting(false);
    }
  };

  return (
    <div className="p-5 rounded-2xl border border-cyan-500/30 bg-[#090d1a] shadow-2xl space-y-5">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold tracking-wider uppercase text-white font-mono flex items-center gap-2">
              Blind Intrusion Test: Quantum Key Exchange & Secret Chat
            </h3>
            <p className="text-xs text-slate-400 font-mono">
              Alice sends a secret message. Bob automatically calculates if an unknown hacker tapped the line!
            </p>
          </div>
        </div>

        <span className="text-[11px] font-mono text-cyan-300 bg-cyan-950/60 px-2.5 py-1 rounded-md border border-cyan-800">
          E91 Protocol + One-Time Pad
        </span>
      </div>

      {/* Input & Quick presets */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Alice Message Composer */}
        <div className="lg:col-span-2 space-y-3">
          <label className="text-xs font-mono font-semibold text-slate-300 flex items-center justify-between">
            <span>Alice's Secret Message (Transmitter TX):</span>
            <span className="text-slate-500 text-[10px]">Encrypted with shared quantum Bell pairs</span>
          </label>

          <div className="flex gap-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type confidential message..."
              className="flex-1 bg-[#060a16] border border-slate-700 focus:border-cyan-400 text-white font-mono text-xs rounded-xl px-3.5 py-2.5 outline-none transition-all shadow-inner"
            />
            
            <button
              onClick={handleTransmit}
              disabled={transmitting || !message.trim()}
              className="px-5 py-2.5 rounded-xl font-mono text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 flex items-center gap-2 shadow-[0_0_15px_rgba(0,242,254,0.35)] transition-all disabled:opacity-50 shrink-0"
            >
              {transmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>TRANSMITTING...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 fill-slate-950" />
                  <span>TRANSMIT VIA QUANTUM LINE</span>
                </>
              )}
            </button>
          </div>

          {/* Quick presets */}
          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            <span className="text-[10px] font-mono text-slate-500 mr-1">Quick Picks:</span>
            {presets.map((p, idx) => (
              <button
                key={idx}
                onClick={() => setMessage(p)}
                className="px-2 py-0.5 rounded text-[10px] font-mono text-slate-400 bg-slate-900 border border-slate-800 hover:border-cyan-500/50 hover:text-cyan-300 transition-colors"
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Test Mode Selector (Simulating Unknown Eavesdropping) */}
        <div className="space-y-2 p-3.5 rounded-xl bg-[#060a16] border border-slate-800">
          <label className="text-xs font-mono font-semibold text-slate-300 block">
            Eavesdropper Presence Mode:
          </label>

          <div className="space-y-1.5">
            <label className={`flex items-center gap-2 p-2 rounded-lg border text-xs font-mono cursor-pointer transition-all ${
              testMode === 'random' ? 'bg-cyan-950/40 border-cyan-500 text-cyan-200' : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800/40'
            }`}>
              <input
                type="radio"
                name="testMode"
                value="random"
                checked={testMode === 'random'}
                onChange={() => setTestMode('random')}
                className="accent-cyan-400"
              />
              <span className="font-bold">🎲 Blind Random Mode</span>
              <span className="text-[10px] text-slate-500 ml-auto">Unknown to Alice & Bob</span>
            </label>

            <label className={`flex items-center gap-2 p-2 rounded-lg border text-xs font-mono cursor-pointer transition-all ${
              testMode === 'clean' ? 'bg-emerald-950/40 border-emerald-500 text-emerald-200' : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800/40'
            }`}>
              <input
                type="radio"
                name="testMode"
                value="clean"
                checked={testMode === 'clean'}
                onChange={() => setTestMode('clean')}
                className="accent-emerald-400"
              />
              <span className="font-bold">🛡️ Guaranteed Clean</span>
              <span className="text-[10px] text-slate-500 ml-auto">No Eavesdropping</span>
            </label>

            <label className={`flex items-center gap-2 p-2 rounded-lg border text-xs font-mono cursor-pointer transition-all ${
              testMode === 'eavesdrop' ? 'bg-red-950/40 border-red-500 text-red-200' : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800/40'
            }`}>
              <input
                type="radio"
                name="testMode"
                value="eavesdrop"
                checked={testMode === 'eavesdrop'}
                onChange={() => setTestMode('eavesdrop')}
                className="accent-red-400"
              />
              <span className="font-bold">⚠️ Secret Hacker Tap</span>
              <span className="text-[10px] text-slate-500 ml-auto">Eve Active</span>
            </label>
          </div>
        </div>

      </div>

      {/* Result Display Box */}
      {result && (
        <div className={`p-4 rounded-xl border transition-all duration-500 ${
          result.isSuccess 
            ? 'bg-emerald-950/20 border-emerald-500/60 shadow-[0_0_20px_rgba(16,185,129,0.15)]' 
            : 'bg-red-950/30 border-red-500/60 shadow-[0_0_20px_rgba(239,68,68,0.25)]'
        } space-y-4`}>
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              {result.isSuccess ? (
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              ) : (
                <ShieldAlert className="w-5 h-5 text-red-400 animate-pulse" />
              )}
              <span className={`text-sm font-bold font-mono ${result.isSuccess ? 'text-emerald-300' : 'text-red-300'}`}>
                {result.isSuccess ? 'MESSAGE VERIFIED & SAFELY RECEIVED BY BOB' : 'SECURITY BREACH DETECTED: KEY ABORTED!'}
              </span>
            </div>

            <div className="flex items-center gap-3 text-xs font-mono">
              <span className="text-slate-400">
                QBER: <strong className={result.metrics.qber > 0.11 ? 'text-red-400' : 'text-emerald-400'}>{(result.metrics.qber * 100).toFixed(1)}%</strong>
              </span>
              <span className="text-slate-400">
                Bell S: <strong className={result.metrics.chshS > 2.0 ? 'text-emerald-400' : 'text-red-400'}>{result.metrics.chshS.toFixed(3)}</strong>
              </span>
              <span className="text-slate-500 text-[10px]">
                Actual Hacker: {result.evePresent ? '🔴 Yes (Tapped)' : '🟢 No (Clean)'}
              </span>
            </div>
          </div>

          {/* Side by side: Alice sent vs Bob received */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Alice Sent Box */}
            <div className="p-3.5 rounded-lg bg-[#060a16] border border-slate-800 space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span className="text-cyan-400 font-bold">ALICE (Transmitter TX):</span>
                <span>Plaintext + Ciphertext</span>
              </div>
              <div className="p-2 rounded bg-slate-900 text-white font-semibold break-all">
                "{result.originalMessage}"
              </div>
              <div className="text-[10px] text-slate-500 break-all">
                One-Time Pad Ciphertext: <span className="text-slate-400 font-mono">{result.ciphertextPreview}</span>
              </div>
            </div>

            {/* Bob Received Box */}
            <div className={`p-3.5 rounded-lg border space-y-1.5 font-mono text-xs ${
              result.isSuccess ? 'bg-emerald-950/30 border-emerald-500/40' : 'bg-red-950/30 border-red-500/50'
            }`}>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span className={result.isSuccess ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                  BOB (Receiver RX):
                </span>
                <span>{result.isSuccess ? 'Decrypted Output' : 'Decryption Refused'}</span>
              </div>
              <div className={`p-2 rounded font-semibold break-all ${
                result.isSuccess ? 'bg-emerald-900/40 text-emerald-200' : 'bg-red-900/40 text-red-300'
              }`}>
                {result.bobDecryptedMessage}
              </div>
              <div className="text-[10px] text-slate-400">
                {result.isSuccess ? (
                  <span className="text-emerald-400">✔ Quantum key 100% genuine. No observer interference.</span>
                ) : (
                  <span className="text-red-400">✖ Wavefunction collapsed by intruder! Data destroyed to protect secrecy.</span>
                )}
              </div>
            </div>

          </div>

          {/* Explanation Banner */}
          <div className="text-xs font-mono text-slate-300 leading-relaxed pt-2 border-t border-slate-800/80">
            <strong>System Verdict: </strong>
            <span className={result.isSuccess ? 'text-emerald-300' : 'text-red-300'}>
              {result.statusText}
            </span>
          </div>

        </div>
      )}

    </div>
  );
}
