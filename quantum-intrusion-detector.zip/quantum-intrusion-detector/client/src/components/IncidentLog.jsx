import React from 'react';
import { AlertOctagon, Check, Trash2, Database, ShieldAlert, MapPin } from 'lucide-react';

export default function IncidentLog({ 
  incidents, 
  onResolve, 
  onClear, 
  dbConnected 
}) {
  return (
    <div className="p-5 rounded-2xl border border-red-500/20 bg-[#090d1a] shadow-xl space-y-4">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <AlertOctagon className="w-4 h-4 text-red-400" />
          <h3 className="text-sm font-bold tracking-wider uppercase text-white font-mono">
            Intrusion Incidents & Security Alerts ({incidents.length})
          </h3>
        </div>

        <div className="flex items-center gap-2.5">
          <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
            <Database className="w-3 h-3 text-cyan-400" />
            <span>Store: {dbConnected ? 'MongoDB Cluster' : 'In-Memory Fallback'}</span>
          </span>

          {incidents.length > 0 && (
            <button
              onClick={onClear}
              className="p-1 rounded text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
              title="Clear Incident History"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Incident List */}
      {incidents.length === 0 ? (
        <div className="p-8 text-center font-mono text-xs text-slate-500">
          No intrusion incidents recorded. All quantum channels operating securely within Bell bounds.
        </div>
      ) : (
        <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
          {incidents.map((inc) => {
            const isResolved = inc.isResolved;

            return (
              <div
                key={inc.incidentId || inc._id}
                className={`p-3.5 rounded-xl border transition-all ${
                  isResolved
                    ? 'bg-slate-900/30 border-slate-800 opacity-60'
                    : inc.severity === 'CRITICAL'
                    ? 'bg-red-950/30 border-red-500/50 shadow-[0_0_12px_rgba(239,68,68,0.2)]'
                    : 'bg-amber-950/20 border-amber-500/40'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-mono font-bold text-white">
                        {inc.incidentId}
                      </span>
                      
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        inc.severity === 'CRITICAL' 
                          ? 'bg-red-500 text-white' 
                          : 'bg-amber-500 text-black'
                      }`}>
                        {inc.severity}
                      </span>

                      <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-cyan-400" />
                        Km {inc.channelLocationKm}
                      </span>

                      <span className="text-[10px] font-mono text-slate-500">
                        {new Date(inc.timestamp).toLocaleTimeString()}
                      </span>
                    </div>

                    <div className="text-xs font-mono text-slate-300">
                      Signature: <span className="text-red-300 font-semibold uppercase">{inc.attackSignature}</span> | 
                      QBER: <span className="text-white font-bold">{(inc.detectedQber * 100).toFixed(1)}%</span> | 
                      CHSH S: <span className="text-white font-bold">{Number(inc.chshValue).toFixed(2)}</span>
                    </div>

                    <p className="text-[11px] font-mono text-slate-400 leading-relaxed pt-1 border-t border-slate-800/60">
                      <strong className="text-cyan-400">Mitigation: </strong>{inc.mitigationAction}
                    </p>
                  </div>

                  {!isResolved && (
                    <button
                      onClick={() => onResolve(inc.incidentId)}
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/40 text-[11px] font-mono flex items-center gap-1 shrink-0 transition-all"
                      title="Apply Mitigation & Mark Resolved"
                    >
                      <Check className="w-3 h-3" />
                      <span>Mitigate</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}
