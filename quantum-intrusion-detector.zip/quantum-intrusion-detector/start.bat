@echo off
title Quantum Entanglement Intrusion Detection Visualizer
echo ========================================================
echo  WO-021: Quantum Entanglement Intrusion Detection (Q-IDS)
echo ========================================================
echo.
echo Starting Backend Server on http://localhost:5000 ...
start "Quantum Server (Port 5000)" cmd /k "cd /d %~dp0server && npm run dev"

timeout /t 2 /nobreak >nul

echo Starting Frontend Visualizer on http://localhost:3000 ...
start "Quantum Visualizer (Port 3000)" cmd /k "cd /d %~dp0client && npm run dev"

echo.
echo ========================================================
echo Both Backend and Client are running!
echo Open your browser at: http://localhost:3000
echo ========================================================
pause
