const mongoose = require('mongoose');

const SimulationRunSchema = new mongoose.Schema({
  title: {
    type: String,
    default: () => `Quantum Run #${Date.now().toString().slice(-4)}`
  },
  config: {
    photonCount: { type: Number, default: 200 },
    channelLengthKm: { type: Number, default: 25 },
    fiberAttenuation: { type: Number, default: 0.2 }, // dB/km
    environmentalNoise: { type: Number, default: 0.02 }, // 0.0 - 0.2
    eveEnabled: { type: Boolean, default: false },
    eveAttackType: { 
      type: String, 
      enum: ['none', 'intercept_resend', 'beam_splitter', 'phase_shift', 'entanglement_swapping'], 
      default: 'none' 
    },
    eveInterceptionRate: { type: Number, default: 0.5 }, // 0.0 - 1.0
    qberThreshold: { type: Number, default: 0.11 }, // 11% standard QKD security limit
    bellThreshold: { type: Number, default: 2.0 }   // CHSH bound (S <= 2 is classical)
  },
  metrics: {
    totalPhotons: Number,
    detectedPhotons: Number,
    siftedKeyBits: Number,
    errorBits: Number,
    qber: Number,                   // e.g. 0.035 = 3.5%
    chshS: Number,                  // e.g. 2.78
    fidelity: Number,               // e.g. 0.985
    vonNeumannEntropy: Number,       // e.g. 0.08
    decoherenceRate: Number,        // e.g. 0.04
    transmissionEfficiency: Number  // e.g. 78.5%
  },
  status: {
    classification: {
      type: String,
      enum: ['SECURE_QUANTUM_CHANNEL', 'ENVIRONMENTAL_NOISE', 'SUSPICIOUS_PROBING', 'CRITICAL_INTRUSION_DETECTED'],
      default: 'SECURE_QUANTUM_CHANNEL'
    },
    isBreach: { type: Boolean, default: false },
    confidence: { type: Number, default: 99.5 },
    recommendation: String
  },
  samplePhotons: [
    {
      index: Number,
      aliceBasis: String, // '+' or 'x'
      aliceBit: Number,   // 0 or 1
      bobBasis: String,
      bobBit: Number,
      eveInterception: Boolean,
      eveMeasuredBasis: String,
      matchBasis: Boolean,
      bitError: Boolean,
      stateCollapse: Boolean
    }
  ],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.models.SimulationRun || mongoose.model('SimulationRun', SimulationRunSchema);
