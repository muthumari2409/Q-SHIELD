const mongoose = require('mongoose');

const IntrusionIncidentSchema = new mongoose.Schema({
  incidentId: {
    type: String,
    unique: true,
    default: () => `INC-${Date.now().toString().slice(-6)}`
  },
  severity: {
    type: String,
    enum: ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'],
    default: 'HIGH'
  },
  attackSignature: {
    type: String,
    required: true
  },
  detectedQber: {
    type: Number,
    required: true
  },
  chshValue: {
    type: Number,
    required: true
  },
  entanglementFidelity: {
    type: Number,
    required: true
  },
  decoherenceDelta: {
    type: Number,
    default: 0
  },
  channelLocationKm: {
    type: Number,
    default: 12.5
  },
  mitigationAction: {
    type: String,
    default: 'Abort key distillation and switch to alternate quantum repeater path.'
  },
  isResolved: {
    type: Boolean,
    default: false
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.models.IntrusionIncident || mongoose.model('IntrusionIncident', IntrusionIncidentSchema);
