const express = require('express');
const router = express.Router();
const simulationController = require('../controllers/simulationController');
const incidentController = require('../controllers/incidentController');
const { getDBStatus } = require('../config/db');

// Simulation routes
router.post('/simulate', simulationController.runSimulation);
router.post('/transmit', simulationController.transmitMessage);
router.get('/simulations', simulationController.getSimulationHistory);
router.get('/presets', simulationController.getPresets);
router.get('/benchmark', simulationController.getBenchmark);

// Incident routes
router.get('/incidents', incidentController.getAllIncidents);
router.patch('/incidents/:id/resolve', incidentController.resolveIncident);
router.delete('/incidents', incidentController.clearIncidents);

// System health and MongoDB status
router.get('/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    service: 'Quantum Entanglement Intrusion Detection Visualizer (Q-IDS Engine)',
    version: '1.0.0',
    database: getDBStatus(),
    quantumProtocols: ['E91-Ekert', 'BB84-Entangled', 'CHSH-Bell-Violation', 'Werner-Depolarization'],
    uptimeSeconds: Math.floor(process.uptime())
  });
});

module.exports = router;
