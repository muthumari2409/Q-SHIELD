const QuantumEngine = require('../quantum-engine/quantumPhysics');
const SimulationRun = require('../models/SimulationRun');
const IntrusionIncident = require('../models/IntrusionIncident');
const { getDBStatus } = require('../config/db');

// In-memory fallback stores in case MongoDB is not yet running
const memorySimulations = [];
const memoryIncidents = [];

// Standard demo presets
const PRESETS = [
  {
    id: 'clean_bell',
    name: '1. Pristine Entangled Bell State (Ideal Channel)',
    description: 'Clean SPDC source, 10km low-loss fiber, zero eavesdropping. Perfect Bell inequality violation (S ~ 2.8).',
    config: {
      photonCount: 200,
      channelLengthKm: 10,
      fiberAttenuation: 0.18,
      environmentalNoise: 0.01,
      eveEnabled: false,
      eveAttackType: 'none',
      eveInterceptionRate: 0.0,
      qberThreshold: 0.11,
      bellThreshold: 2.0
    }
  },
  {
    id: 'fiber_thermal_noise',
    name: '2. Long-Haul Realistic Fiber Noise (50km)',
    description: 'Standard telecommunication fiber with thermal polarization drift. S > 2.0 persists despite minor attenuation.',
    config: {
      photonCount: 300,
      channelLengthKm: 50,
      fiberAttenuation: 0.22,
      environmentalNoise: 0.07,
      eveEnabled: false,
      eveAttackType: 'none',
      eveInterceptionRate: 0.0,
      qberThreshold: 0.11,
      bellThreshold: 2.0
    }
  },
  {
    id: 'beam_splitter_tap',
    name: '3. Passive Beam-Splitter Tap (Photon Number Splitting)',
    description: 'Eve taps 30% of photon beam to intercept multiphoton pulses. Causes elevated QBER (~7-9%) and degraded fidelity.',
    config: {
      photonCount: 250,
      channelLengthKm: 25,
      fiberAttenuation: 0.2,
      environmentalNoise: 0.03,
      eveEnabled: true,
      eveAttackType: 'beam_splitter',
      eveInterceptionRate: 0.35,
      qberThreshold: 0.11,
      bellThreshold: 2.0
    }
  },
  {
    id: 'intercept_resend_attack',
    name: '4. Active Intercept-Resend Attack (Critical Breach)',
    description: 'Eve intercepts 80% of photons and measures them, destroying the quantum entanglement wavefunction. QBER spikes > 20%, S drops below 2.0.',
    config: {
      photonCount: 300,
      channelLengthKm: 30,
      fiberAttenuation: 0.2,
      environmentalNoise: 0.02,
      eveEnabled: true,
      eveAttackType: 'intercept_resend',
      eveInterceptionRate: 0.8,
      qberThreshold: 0.11,
      bellThreshold: 2.0
    }
  },
  {
    id: 'phase_perturbation',
    name: '5. Quantum Phase Perturbation / Man-In-The-Middle',
    description: 'Eve introduces coherent phase drift attempting non-destructive eavesdropping. Detected via diagonal basis error surge.',
    config: {
      photonCount: 250,
      channelLengthKm: 35,
      fiberAttenuation: 0.2,
      environmentalNoise: 0.04,
      eveEnabled: true,
      eveAttackType: 'phase_shift',
      eveInterceptionRate: 0.65,
      qberThreshold: 0.11,
      bellThreshold: 2.0
    }
  }
];

exports.getPresets = (req, res) => {
  res.json({ success: true, presets: PRESETS });
};

exports.runSimulation = async (req, res) => {
  try {
    const config = req.body || {};
    const result = QuantumEngine.simulateTransmission(config);

    const isConnected = getDBStatus().connected;
    let savedRun = null;
    let newIncident = null;

    // Check if intrusion is detected
    if (result.status.isBreach) {
      const incidentData = {
        incidentId: `INC-${Date.now().toString().slice(-6)}`,
        severity: result.metrics.qber > 0.18 || result.metrics.chshS < 1.8 ? 'CRITICAL' : 'HIGH',
        attackSignature: config.eveAttackType || 'ANOMALOUS_DECOHERENCE',
        detectedQber: result.metrics.qber,
        chshValue: result.metrics.chshS,
        entanglementFidelity: result.metrics.fidelity,
        decoherenceDelta: result.metrics.decoherenceRate,
        channelLocationKm: Math.round((config.channelLengthKm || 25) * 0.45),
        mitigationAction: result.status.recommendation,
        timestamp: new Date()
      };

      if (isConnected) {
        try {
          newIncident = await IntrusionIncident.create(incidentData);
        } catch (e) {
          console.error('[DB Error]', e.message);
          memoryIncidents.unshift(incidentData);
        }
      } else {
        memoryIncidents.unshift(incidentData);
        newIncident = incidentData;
      }
    }

    if (isConnected) {
      try {
        savedRun = await SimulationRun.create({
          title: `Run ${new Date().toLocaleTimeString()} - ${result.status.classification}`,
          config: result.config,
          metrics: result.metrics,
          status: result.status,
          samplePhotons: result.samplePhotons
        });
      } catch (e) {
        console.error('[DB Error]', e.message);
        memorySimulations.unshift(result);
      }
    } else {
      memorySimulations.unshift({
        _id: `mem-${Date.now()}`,
        title: `Run ${new Date().toLocaleTimeString()} - ${result.status.classification}`,
        ...result,
        createdAt: new Date()
      });
    }

    res.json({
      success: true,
      data: result,
      incident: newIncident,
      persistedInMongoDB: isConnected
    });
  } catch (error) {
    console.error('Simulation error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getSimulationHistory = async (req, res) => {
  try {
    const isConnected = getDBStatus().connected;
    if (isConnected) {
      const runs = await SimulationRun.find().sort({ createdAt: -1 }).limit(20);
      return res.json({ success: true, count: runs.length, runs, source: 'MongoDB' });
    }
    res.json({ success: true, count: memorySimulations.length, runs: memorySimulations.slice(0, 20), source: 'InMemory' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getBenchmark = (req, res) => {
  try {
    const trials = parseInt(req.query.trials) || 40;
    const benchmarkData = QuantumEngine.runBenchmarkSuite(trials);
    res.json({ success: true, benchmark: benchmarkData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.transmitMessage = async (req, res) => {
  try {
    const { message, mode } = req.body;
    const result = QuantumEngine.transmitConfidentialMessage(message, mode);

    const isConnected = getDBStatus().connected;
    let newIncident = null;

    if (result.detectedByBob) {
      const incidentData = {
        incidentId: `INC-${Date.now().toString().slice(-6)}`,
        severity: 'CRITICAL',
        attackSignature: 'BLIND_INTERCEPT_KEY_COLLAPSE',
        detectedQber: result.metrics.qber,
        chshValue: result.metrics.chshS,
        entanglementFidelity: result.metrics.fidelity,
        decoherenceDelta: result.metrics.decoherenceRate,
        channelLocationKm: 12.5,
        mitigationAction: 'Confidential message destroyed. Key distillation aborted to protect data secrecy.',
        timestamp: new Date()
      };

      if (isConnected) {
        try {
          newIncident = await IntrusionIncident.create(incidentData);
        } catch (e) {
          memoryIncidents.unshift(incidentData);
        }
      } else {
        memoryIncidents.unshift(incidentData);
        newIncident = incidentData;
      }
    }

    res.json({
      success: true,
      data: result,
      incident: newIncident,
      persistedInMongoDB: isConnected
    });
  } catch (error) {
    console.error('Transmit message error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
};
