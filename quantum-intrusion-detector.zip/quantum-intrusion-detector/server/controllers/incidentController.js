const IntrusionIncident = require('../models/IntrusionIncident');
const { getDBStatus } = require('../config/db');

// Seed dummy initial incidents if empty
const seedIncidents = [
  {
    incidentId: 'INC-904128',
    severity: 'CRITICAL',
    attackSignature: 'intercept_resend',
    detectedQber: 0.245,
    chshValue: 1.482,
    entanglementFidelity: 0.542,
    decoherenceDelta: 0.812,
    channelLocationKm: 14.2,
    mitigationAction: 'Wavefunction collapse detected. Aborted key transmission. Rerouted via node Gamma.',
    isResolved: true,
    timestamp: new Date(Date.now() - 3600000 * 2)
  },
  {
    incidentId: 'INC-904129',
    severity: 'HIGH',
    attackSignature: 'beam_splitter',
    detectedQber: 0.124,
    chshValue: 1.985,
    entanglementFidelity: 0.781,
    decoherenceDelta: 0.450,
    channelLocationKm: 22.0,
    mitigationAction: 'Beam tapping detected. Switched to decoy state protocol with active phase randomization.',
    isResolved: false,
    timestamp: new Date(Date.now() - 1800000)
  }
];

let memoryIncidents = [...seedIncidents];

exports.getAllIncidents = async (req, res) => {
  try {
    const isConnected = getDBStatus().connected;
    if (isConnected) {
      let incidents = await IntrusionIncident.find().sort({ timestamp: -1 });
      if (incidents.length === 0) {
        // Seed initial
        await IntrusionIncident.insertMany(seedIncidents);
        incidents = await IntrusionIncident.find().sort({ timestamp: -1 });
      }
      return res.json({ success: true, count: incidents.length, incidents, source: 'MongoDB' });
    }
    res.json({ success: true, count: memoryIncidents.length, incidents: memoryIncidents, source: 'InMemory' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.resolveIncident = async (req, res) => {
  try {
    const { id } = req.params;
    const isConnected = getDBStatus().connected;

    if (isConnected) {
      const updated = await IntrusionIncident.findOneAndUpdate(
        { incidentId: id },
        { isResolved: true },
        { new: true }
      );
      if (updated) {
        return res.json({ success: true, incident: updated });
      }
    }

    const item = memoryIncidents.find(i => i.incidentId === id);
    if (item) {
      item.isResolved = true;
      return res.json({ success: true, incident: item });
    }

    res.status(404).json({ success: false, message: 'Incident not found' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.clearIncidents = async (req, res) => {
  try {
    const isConnected = getDBStatus().connected;
    if (isConnected) {
      await IntrusionIncident.deleteMany({});
    }
    memoryIncidents = [];
    res.json({ success: true, message: 'All incidents cleared' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
