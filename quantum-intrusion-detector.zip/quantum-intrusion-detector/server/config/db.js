const mongoose = require('mongoose');

let isConnected = false;

const connectDB = async () => {
  const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/quantum_ids';
  
  try {
    const conn = await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 2500, // Quick timeout so server doesn't hang if Mongo isn't running
    });
    isConnected = true;
    console.log(`[MongoDB] Connected successfully: ${conn.connection.host}`);
  } catch (err) {
    isConnected = false;
    console.warn(`[MongoDB] Notice: Could not connect to MongoDB at ${mongoURI}.`);
    console.warn(`[MongoDB] Running in In-Memory / Standalone Fallback mode. When you launch MongoDB, it will automatically connect!`);
  }
};

const getDBStatus = () => ({
  connected: isConnected,
  host: isConnected ? mongoose.connection.host : 'Offline (In-Memory Fallback Active)',
  name: isConnected ? mongoose.connection.name : 'quantum_ids',
  timestamp: new Date().toISOString()
});

module.exports = { connectDB, getDBStatus };
