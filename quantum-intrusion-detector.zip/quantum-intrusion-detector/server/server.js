const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
require('dotenv').config();

const { connectDB, getDBStatus } = require('./config/db');
const apiRoutes = require('./routes/api');
const QuantumEngine = require('./quantum-engine/quantumPhysics');

const app = express();
const server = http.createServer(app);

// Cross-Origin Resource Sharing
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PATCH', 'DELETE', 'PUT']
}));
app.use(express.json());

// Attach API Routes
app.use('/api', apiRoutes);

// Socket.io for Real-Time Photon Streaming
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

io.on('connection', (socket) => {
  console.log(`[Socket.io] Client connected: ${socket.id}`);

  // Emit current DB and engine status
  socket.emit('system_status', {
    db: getDBStatus(),
    engine: 'READY'
  });

  // Client requests real-time continuous quantum stream
  let streamInterval = null;

  socket.on('start_live_stream', (config) => {
    if (streamInterval) clearInterval(streamInterval);

    console.log(`[Stream] Starting continuous quantum stream for client: ${socket.id}`);

    let photonIndex = 1;
    streamInterval = setInterval(() => {
      // Simulate single photon pair propagation
      const singleRun = QuantumEngine.simulateTransmission({
        ...config,
        photonCount: 4 // small batch per tick for smooth 60fps-like stream
      });

      socket.emit('photon_packet', {
        batchId: Date.now(),
        photons: singleRun.samplePhotons,
        metrics: singleRun.metrics,
        status: singleRun.status
      });

      photonIndex += 4;
    }, 400); // 400ms tick for readable real-time animation
  });

  socket.on('stop_live_stream', () => {
    if (streamInterval) {
      clearInterval(streamInterval);
      streamInterval = null;
      console.log(`[Stream] Stopped stream for: ${socket.id}`);
    }
  });

  socket.on('disconnect', () => {
    if (streamInterval) clearInterval(streamInterval);
    console.log(`[Socket.io] Client disconnected: ${socket.id}`);
  });
});

const PORT = process.env.PORT || 5000;

// Connect to MongoDB and start HTTP/WebSocket server
connectDB().then(() => {
  server.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(` Quantum Entanglement Intrusion Detection Visualizer `);
    console.log(` Backend Server running on http://localhost:${PORT}  `);
    console.log(` WebSocket Server active for real-time quantum stream `);
    console.log(` MongoDB Status: ${getDBStatus().host}               `);
    console.log(`=======================================================`);
  });
});
