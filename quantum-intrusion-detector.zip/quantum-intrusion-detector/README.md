# WO-021: Quantum Entanglement-Based Intrusion Detection Visualizer (Q-IDS)

A full-stack, real-time interactive prototype that models **quantum-state decoherence** when an intruder (Eve) attempts to intercept an entangled photon-pair communication line between Alice (Transmitter) and Bob (Receiver).

---

## 🌟 Key Features & Expected MVP Implementation

1. **User Input & Configuration Module:**
   - **Fiber Channel Modeling:** Adjustable fiber length (2–100 km), fiber attenuation ($0.2\text{ dB/km}$ standard telecom 1550nm fiber), and thermal/polarization drift.
   - **Intrusion Injection Engine (Eve):** Toggle eavesdropping, select from 4 attack models:
     - *Intercept-Resend* (Wavefunction measurement collapse)
     - *Beam Splitter Tap* (Photon Number Splitting - PNS)
     - *Quantum Phase Perturbation* (Coherent drift)
     - *Entanglement Swapping / State Hijack*
   - Configurable eavesdropping probability (5% to 100%).
   - Security ceilings: QBER limit ($11\%$) and CHSH Bell inequality threshold ($S = 2.0$).

2. **Core Detection, Analysis & Classification Engine:**
   - **Bell State Generator:** Produces entangled pairs $|\Phi^+\rangle = \frac{1}{\sqrt{2}}(|00\rangle + |11\rangle)$.
   - **CHSH Bell Inequality Test:** Computes correlation coefficient $S = E(a_1, b_1) - E(a_1, b_2) + E(a_2, b_1) + E(a_2, b_2)$.
     - $S \approx 2\sqrt{2} \approx 2.828$: Genuine quantum entanglement verified (Violates Bell's inequality, channel is safe).
     - $S \le 2.0$: Wavefunction collapsed into classical domain by an observer (Intruder detected!).
   - **Quantum Bit Error Rate (QBER):** Real-time bit mismatch tracking in sifted bases ($0^\circ, 45^\circ$).
   - **Density Matrix ($\rho$) & State Fidelity ($F$):** Evaluates purity $\text{Tr}(\rho^2)$ and Von Neumann Entropy $S(\rho)$.

3. **Results Dashboard & Security Alerts:**
   - **Animated HTML5 Canvas:** Live photon wavepackets traversing fiber optic line, with visual wavefunction collapse bursts upon Eve's intercept.
   - **Telemetry HUD:** Live QBER gauge, CHSH boundary indicator, Fidelity meter, and Entropy metrics.
   - **Incident Log & Mitigation Engine:** Real-time alert feed with automated defense recommendations (e.g., abort key exchange, switch to alternate quantum repeater path).
   - **Exportable Audit Report:** Download formal JSON or printable PDF security audits.

4. **Demo Scenarios & Benchmarks:**
   - 5 preconfigured scenarios (Pristine Bell State, 50km Fiber Noise, Passive Beam Splitter, Active Intercept-Resend, Phase Perturbation).
   - Monte Carlo statistical evaluation engine across varying tap probabilities (0% to 100%).

5. **Backend & MongoDB Database:**
   - **Node.js + Express + Socket.io + Mongoose**
   - Stores simulation runs (`SimulationRun`), intrusion alerts (`IntrusionIncident`), and benchmark logs in MongoDB.
   - **Automatic In-Memory Fallback:** If MongoDB is offline, the app continues to operate flawlessly and automatically resumes persistence once connected.

---

## 🚀 How to Open in Visual Studio Code (VS Code)

### Step 1: Open Terminal and navigate to the project
```powershell
cd "C:\Users\Muthumari\.gemini\antigravity\scratch\quantum-intrusion-detector"
code .
```

### Step 2: Connect MongoDB (Local or Atlas)
You can use MongoDB locally or in the cloud:
- **Option A: Local MongoDB**
  Make sure your local MongoDB service is running:
  ```powershell
  mongod
  ```
- **Option B: MongoDB Atlas (Cloud Free Cluster)**
  Open `server/.env` and paste your MongoDB Atlas connection string:
  ```env
  MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/quantum_ids?retryWrites=true&w=majority
  ```

### Step 3: Run the Application
Open two terminals in VS Code:

- **Terminal 1 (Backend Server):**
  ```powershell
  cd server
  npm run dev
  ```
  *(Server starts on `http://localhost:5000`)*

- **Terminal 2 (Frontend Visualizer):**
  ```powershell
  cd client
  npm run dev
  ```
  *(Frontend starts on `http://localhost:3000`)*

### Step 4: Open in Browser
Visit **`http://localhost:3000`** in your browser.

> **Tip (Windows One-Click Launch):** You can also just double-click `start.bat` in the project root to start both backend and frontend automatically!

---

## 📁 Project Structure

```
quantum-intrusion-detector/
├── .vscode/
│   ├── launch.json           # F5 debug configuration for VS Code
│   └── tasks.json            # Automated VS Code build/start tasks
├── server/
│   ├── config/
│   │   └── db.js             # MongoDB connection with in-memory fallback
│   ├── models/
│   │   ├── SimulationRun.js  # Mongoose schema for simulation logs
│   │   └── IntrusionIncident.js # Mongoose schema for security alerts
│   ├── quantum-engine/
│   │   └── quantumPhysics.js # Core quantum physics & CHSH Bell test engine
│   ├── controllers/
│   │   ├── simulationController.js
│   │   └── incidentController.js
│   ├── routes/
│   │   └── api.js            # REST API endpoints
│   ├── server.js             # Express & Socket.io server
│   ├── .env                  # Environment variables
│   └── package.json
├── client/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx
│   │   │   ├── QuantumCanvas.jsx     # Live HTML5 wavepacket collapse animation
│   │   │   ├── MetricCard.jsx        # Telemetry HUD
│   │   │   ├── ControlPanel.jsx      # Channel & Eve configuration
│   │   │   ├── BellStateVisualizer.jsx # Density matrix & CHSH gauge
│   │   │   ├── PhotonStreamTable.jsx # Sifted key packet inspector
│   │   │   ├── IncidentLog.jsx       # Alert feed with MongoDB persistence
│   │   │   ├── BenchmarkModal.jsx    # Monte Carlo evaluation
│   │   │   ├── ReportExportModal.jsx # Export audit report
│   │   │   └── VSCodeGuideModal.jsx  # Interactive guide modal
│   │   ├── services/
│   │   │   └── api.js                # API client
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── package.json
├── start.bat                 # Windows double-click runner
├── package.json              # Root orchestration script
└── README.md
```

---

## 🔬 Scientific & Theoretical Foundations
- **Ekert (E91) Protocol:** Uses entangled Einstein-Podolsky-Rosen (EPR) pairs.
- **Bell-CHSH Inequality:** Clauser-Horne-Shimony-Holt parameter $S \le 2$ (classical) vs $S \le 2\sqrt{2} \approx 2.8284$ (Cirel'son bound for quantum entangled states).
- **No-Cloning Theorem & State Collapse:** Projective measurement $\hat{M}_E$ destroys coherence, perturbing fidelity $F = \langle \Phi^+ | \rho | \Phi^+ \rangle$.
- **Security Threshold:** QBER $> 11.0\%$ or $S \le 2.0$ immediately triggers automated key cancellation and route switching.
